package com.example.renzo.foodtruck;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;

public class MainActivity extends AppCompatActivity {

    RadioButton selectTallarinesVerdes;
    RadioButton selectArrozConPollo;

    Button btn_realizarPedido;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        selectTallarinesVerdes = (RadioButton)findViewById(R.id.rbtn_ensalada);
        selectArrozConPollo = (RadioButton)findViewById(R.id.rbtn_sopa);


      btn_realizarPedido = (Button)findViewById(R.id.btn_realizarPedido);
      btn_realizarPedido.setOnClickListener(new View.OnClickListener() {

          @Override
          public void onClick(View view) {








              //primer plato
              Intent sendIntent = new Intent();
              sendIntent.setAction(Intent.ACTION_SEND);
              sendIntent.putExtra(Intent.EXTRA_TEXT, selectTallarinesVerdes.getText().toString());
              sendIntent.setType("text/plain");

              if (null != sendIntent.resolveActivity(getPackageManager())) {
                  startActivity(Intent.createChooser(sendIntent, getResources().getText(R.string.send_to)));
              }


                    //primer plato
                  Intent sendIntent1 = new Intent();
                  sendIntent1.setAction(Intent.ACTION_SEND);
                  sendIntent1.putExtra(Intent.EXTRA_TEXT, selectArrozConPollo.getText().toString());
                  sendIntent1.setType("text/plain");

                  if (null != sendIntent1.resolveActivity(getPackageManager())) {
                      startActivity(Intent.createChooser(sendIntent1, getResources().getText(R.string.send_to)));
                  }
              }


















      });





    } // end OnCrete






}


