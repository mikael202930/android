package com.example.renzo.recibefoodtruck;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        // PUNTO 33
        // Obtenemos el intent,
        // la acción y el tipo MIME
        Intent intent = getIntent();
        String action = intent.getAction();
        String type = intent.getType();

        if(Intent.ACTION_SEND.equals(action) && type != null){
            if("text/plain".equals(type)){

                // manipulamos la cadena enviada
                manipularTexto(intent);
            }
        }

    }// end onCreate



    public void manipularTexto(Intent intent){


        String sharedText = intent.getStringExtra(Intent.EXTRA_TEXT);
        if(sharedText != null){


            TextView  txtResultado =(TextView)findViewById(R.id.txtMuestraEntrada);
            txtResultado.setText(" "+ sharedText);

            //Toast.makeText(MainActivity.this,sharedText,Toast.LENGTH_LONG).show();
        }
    }





















}
